/**
 * This functions loads the Image in the HTML component.
 */
function loadImage(){
   document.getElementById("imgProduct").src = document.getElementById("url").value;
}