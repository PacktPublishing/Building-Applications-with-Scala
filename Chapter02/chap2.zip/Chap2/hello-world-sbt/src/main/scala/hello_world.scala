object SbtScalaMainApp extends App {
  println("Hellow world SBT / Scala App ")
}
