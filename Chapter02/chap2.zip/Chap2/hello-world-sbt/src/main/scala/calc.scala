class Calculator{
	def sum(a:Int,b:Int):Int = {
		return a + b
	}
	def multiply(a:Int,b:Int):Int = {
		return a * b
	}
}